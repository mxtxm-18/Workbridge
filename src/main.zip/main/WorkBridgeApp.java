package main;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class WorkBridgeApp extends JFrame {

    private CardLayout cardLayout;
    private JPanel mainPanel;
    private Map<String, Component> screens;

    private String usuarioIdSesion = null;
    private String rolSesion = null;

    public WorkBridgeApp() {
        setTitle("Work Bridge");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setPreferredSize(new Dimension(1920, 1080));
        setMinimumSize(new Dimension(1920, 1080));
        setSize(1920, 1080);

        setLocationRelativeTo(null);
        setResizable(true);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        screens = new HashMap<>();

        initializeScreens();
        setContentPane(mainPanel);
        mostrarPantalla("registro");
    }

    private void initializeScreens() {
        screens.put("registro", new Registro(this));
        screens.put("publicaciones", new Publicaciones(this));
        screens.put("perfilTrabajador", new PerfilPublicoTrabajador(this));
        screens.put("documentos", new GestionDocumentos(this));
        screens.put("notificaciones", new Notificaciones(this));
        screens.put("comunicaciones", new Comunicaciones(this));
        screens.put("dashboardAdmin", new DashboardAdmin(this));
        screens.put("gestionUsuarios", new GestionUsuarios(this));
        screens.put("empresas", new VerificacionEmpresas(this));
        screens.put("habilidades", new GestionHabilidades(this));
        screens.put("dashboardEmpresa", new DashboardEmpresa(this));
        screens.put("dashboardModerador", new DashboardModerador(this));
        screens.put("gestionEmpresa", new Gestion_Empresa(this));
        screens.put("perfilUsuario", new PerfilUsuario(this));

        for (Map.Entry<String, Component> entry : screens.entrySet()) {
            mainPanel.add(entry.getValue(), entry.getKey());
        }
    }

    public void reemplazarPantalla(String nombre, JPanel nuevoPanel) {
        if (screens.containsKey(nombre)) {
            mainPanel.remove(screens.get(nombre));
        }
        screens.put(nombre, nuevoPanel);
        mainPanel.add(nuevoPanel, nombre);
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    public void mostrarPantalla(String nombrePantalla) {
        if (screens.containsKey(nombrePantalla)) {
            cardLayout.show(mainPanel, nombrePantalla);
        } else {
            System.err.println("Pantalla no encontrada: " + nombrePantalla);
        }
    }

    // Acceso rápido para el ícono de la campanita: lleva siempre a Notificaciones.
    public void irANotificaciones() {
        mostrarPantalla("notificaciones");
    }

    // Acceso rápido para el ícono de perfil: según el rol en sesión, lleva al
    // perfil de empresa (reclutador) o al perfil de trabajador (resto de roles).
    public void irAPerfil() {
        if ("reclutador".equals(rolSesion)) {
            mostrarPantalla("gestionEmpresa");
        } else {
            mostrarPantalla("perfilUsuario");
        }
    }

    public void iniciarSesion(String usuarioId, String rol) {
        this.usuarioIdSesion = usuarioId;
        this.rolSesion = rol;

        reemplazarPantalla("publicaciones", new Publicaciones(this));
        reemplazarPantalla("perfilTrabajador", new PerfilPublicoTrabajador(this));
        reemplazarPantalla("documentos", new GestionDocumentos(this));
        reemplazarPantalla("notificaciones", new Notificaciones(this));
        reemplazarPantalla("comunicaciones", new Comunicaciones(this));
        reemplazarPantalla("dashboardAdmin", new DashboardAdmin(this));
        reemplazarPantalla("dashboardEmpresa", new DashboardEmpresa(this));
        reemplazarPantalla("gestionUsuarios", new GestionUsuarios(this));
        reemplazarPantalla("empresas", new VerificacionEmpresas(this));
        reemplazarPantalla("habilidades", new GestionHabilidades(this));
        reemplazarPantalla("dashboardModerador", new DashboardModerador(this));
        reemplazarPantalla("gestionEmpresa", new Gestion_Empresa(this));
        reemplazarPantalla("perfilUsuario", new PerfilUsuario(this));

        switch (rol) {
            case "admin" -> mostrarPantalla("dashboardAdmin");
            case "reclutador" -> mostrarPantalla("dashboardEmpresa");
            case "moderador" -> mostrarPantalla("dashboardModerador");
            default -> mostrarPantalla("publicaciones");
        }
    }

    public String getUsuarioIdSesion() {
        return usuarioIdSesion;
    }

    public String getRolSesion() {
        return rolSesion;
    }

    public void cerrarSesion() {
        usuarioIdSesion = null;
        rolSesion = null;
        mostrarPantalla("registro");
    }
}